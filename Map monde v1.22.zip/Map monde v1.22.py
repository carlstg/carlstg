# Example using PIO to drive a set of WS2812 LEDs.

import array, time
from machine import Pin
import rp2

relay1 = machine.Pin(16)
relay2 = machine.Pin(17)
relay1.value(1)
relay2.value(1)
relay1 = machine.Pin(16, machine.Pin.OUT, machine.Pin.PULL_UP)
relay2 = machine.Pin(17, machine.Pin.OUT, machine.Pin.PULL_UP)

button1 = Pin(13, Pin.IN, Pin.PULL_UP)
button2 = Pin(14, Pin.IN, Pin.PULL_UP)
button3 = Pin(15, Pin.IN, Pin.PULL_UP)
led = Pin(25, Pin.OUT)

# Configure the number of WS2812 LEDs.
NUM_LEDS = 10
PIN_NUM1 = 6
PIN_NUM2 = 7
PIN_NUM3 = 8
PIN_NUM4 = 9
PIN_NUM5 = 10
brightness = 0.2

@rp2.asm_pio(sideset_init=rp2.PIO.OUT_LOW, out_shiftdir=rp2.PIO.SHIFT_LEFT, autopull=True, pull_thresh=24)
def ws2812():
    T1 = 2
    T2 = 5
    T3 = 3
    wrap_target()
    label("bitloop")
    out(x, 1)               .side(0)    [T3 - 1]
    jmp(not_x, "do_zero")   .side(1)    [T1 - 1]
    jmp("bitloop")          .side(1)    [T2 - 1]
    label("do_zero")
    nop()                   .side(0)    [T2 - 1]
    wrap()


# Create the StateMachine with the ws2812 program, outputting on pin
sm1 = rp2.StateMachine(0, ws2812, freq=8_000_000, sideset_base=Pin(PIN_NUM1))
sm2 = rp2.StateMachine(1, ws2812, freq=8_000_000, sideset_base=Pin(PIN_NUM2))
sm3 = rp2.StateMachine(2, ws2812, freq=8_000_000, sideset_base=Pin(PIN_NUM3))
sm4 = rp2.StateMachine(3, ws2812, freq=8_000_000, sideset_base=Pin(PIN_NUM4))
sm5 = rp2.StateMachine(4, ws2812, freq=8_000_000, sideset_base=Pin(PIN_NUM5))

# Start the StateMachine, it will wait for data on its FIFO.
sm1.active(1)
sm2.active(1)
sm3.active(1)
sm4.active(1)
sm5.active(1)

# Display a pattern on the LEDs via an array of LED RGB values.
ar = array.array("I", [0 for _ in range(NUM_LEDS)])

##########################################################################
def pixels_show1():
    dimmer_ar = array.array("I", [0 for _ in range(NUM_LEDS)])
    for i,c in enumerate(ar):
        r = int(((c >> 8) & 0xFF) * brightness)
        g = int(((c >> 16) & 0xFF) * brightness)
        b = int((c & 0xFF) * brightness)
        dimmer_ar[i] = (g<<16) + (r<<8) + b
    sm1.put(dimmer_ar, 8)
    time.sleep_ms(10)
    
def pixels_show2():
    dimmer_ar = array.array("I", [0 for _ in range(NUM_LEDS)])
    for i,c in enumerate(ar):
        r = int(((c >> 8) & 0xFF) * brightness)
        g = int(((c >> 16) & 0xFF) * brightness)
        b = int((c & 0xFF) * brightness)
        dimmer_ar[i] = (g<<16) + (r<<8) + b
    sm2.put(dimmer_ar, 8)
    time.sleep_ms(10)

def pixels_show3():
    dimmer_ar = array.array("I", [0 for _ in range(NUM_LEDS)])
    for i,c in enumerate(ar):
        r = int(((c >> 8) & 0xFF) * brightness)
        g = int(((c >> 16) & 0xFF) * brightness)
        b = int((c & 0xFF) * brightness)
        dimmer_ar[i] = (g<<16) + (r<<8) + b
    sm3.put(dimmer_ar, 8)
    time.sleep_ms(10)
    
def pixels_show4():
    dimmer_ar = array.array("I", [0 for _ in range(NUM_LEDS)])
    for i,c in enumerate(ar):
        r = int(((c >> 8) & 0xFF) * brightness)
        g = int(((c >> 16) & 0xFF) * brightness)
        b = int((c & 0xFF) * brightness)
        dimmer_ar[i] = (g<<16) + (r<<8) + b
    sm4.put(dimmer_ar, 8)
    time.sleep_ms(10)
    
def pixels_show5():
    dimmer_ar = array.array("I", [0 for _ in range(NUM_LEDS)])
    for i,c in enumerate(ar):
        r = int(((c >> 8) & 0xFF) * brightness)
        g = int(((c >> 16) & 0xFF) * brightness)
        b = int((c & 0xFF) * brightness)
        dimmer_ar[i] = (g<<16) + (r<<8) + b
    sm5.put(dimmer_ar, 8)
    time.sleep_ms(10)

def pixels_set(i, color):
    ar[i] = (color[1]<<16) + (color[0]<<8) + color[2]

def pixels_fill(color):
    for i in range(len(ar)):
        pixels_set(i, color)
        
def color_chase1(color, wait):
    for i in range(NUM_LEDS):
        pixels_set(i, color)
        time.sleep(wait)
        pixels_show1()

def color_chase2(color, wait):
    for i in range(NUM_LEDS):
        pixels_set(i, color)
        time.sleep(wait)
        pixels_show2()
        
def color_chase3(color, wait):
    for i in range(NUM_LEDS):
        pixels_set(i, color)
        time.sleep(wait)
        pixels_show3()

def color_chase4(color, wait):
    for i in range(NUM_LEDS):
        pixels_set(i, color)
        time.sleep(wait)
        pixels_show4()

def color_chase5(color, wait):
    for i in range(NUM_LEDS):
        pixels_set(i, color)
        time.sleep(wait)
        pixels_show5()
    
BLACK = (0, 0, 0)
RED = (0, 255, 0)
YELLOW = (255, 150, 0)
GREEN = (255, 0, 0)
CYAN = (0, 255, 255)
BLUE = (0, 0, 255)
PURPLE = (180, 0, 255)
WHITE = (255, 255, 255)
# COLORS = (BLACK, RED, YELLOW, GREEN, CYAN, BLUE, PURPLE, BLACK)
COLORS = (GREEN, BLACK)

 
###############################
               

for i in range(1):
    print("TESTING ALL STRIP LED")
    pixels_fill(WHITE)
    led.value(1)
    pixels_show1()
    time.sleep(0.5)
    pixels_show2()
    time.sleep(0.5)
    pixels_show3()
    time.sleep(0.5)
    pixels_show4()
    time.sleep(0.5)
    pixels_show5()
    time.sleep(0.5)
    pixels_fill(BLACK)
    led.value(0)
    pixels_show1()
    time.sleep(0.25)
    pixels_show2()
    time.sleep(0.25)
    pixels_show3()
    time.sleep(0.25)
    pixels_show4()
    time.sleep(0.25)
    pixels_show5()
    time.sleep(0.25)
    print("LED LIGHT UP ALL TEST")
    

try:
    while(1):
        if not button1.value():
                print("country1")
                relay1.off()
                led.value(0)   
                color_chase1(BLUE, 0.2)
                print("country1 ledstrip1 done")
                time.sleep(0.25)
                pixels_fill(BLACK)
                color_chase2(BLUE, 0.2)
                print("country1 ledstrip2 done")
                time.sleep(2)
                relay1.on()            
                                                                             
        elif not button2.value():
                print("country2")
                relay2.off()
                led.value(0)   
                color_chase1(BLUE, 0.2)
                relay2.on()
                print("country2 ledstrip1 done")
                time.sleep(0.25)
                pixels_fill(BLACK)
                color_chase2(BLUE, 0.2)
                print("country2 ledstrip2 done")
                time.sleep(0.25)
                pixels_fill(BLACK)
                color_chase3(BLUE, 0.2)
                print("country2 ledstrip3 done")
                time.sleep(2)
                
        elif not button3.value():
                print("country3")
                relay1.off()
                led.value(0)   
                color_chase1(BLUE, 0.2)
                relay1.on()
                print("country3 ledstrip1 done")
                time.sleep(0.25)
                pixels_fill(BLACK)
                color_chase2(BLUE, 0.2)
                print("country3 ledstrip2 done")
                time.sleep(0.25)
                pixels_fill(BLACK)
                color_chase3(BLUE, 0.2)
                print("country3 ledstrip3 done")
                time.sleep(0.25)
                pixels_fill(BLACK)
                color_chase4(BLUE, 0.2)
                print("country3 ledstrip4 done")
                time.sleep(0.25)
                pixels_fill(BLACK)
                color_chase5(BLUE, 0.2)
                print("country3 ledstrip5 done")
                time.sleep(2)
                
        else:
            pixels_fill(BLACK)
            pixels_show1()
            pixels_show2()
            pixels_show3()
            pixels_show4()
            pixels_show5()
            led.value(1)     
                       
except:
    pass
